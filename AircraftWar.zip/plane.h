#ifndef PLANE_H
#define PLANE_H
#include <QPixmap>
#include <QRect>

class Plane
{
public:
    Plane();

    void shoot();
    void setPosition(int x, int y);

    QPixmap plane;  // 飞机图片对象

    int planeX;
    int planeY;

    QRect rect;  //飞机的矩形边框
};

#endif // PLANE_H
