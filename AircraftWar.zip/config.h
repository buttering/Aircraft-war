#ifndef CONFIG_H
#define CONFIG_H
#define WIN_WIDTH 500  // 窗口宽度
#define WIN_HEIGHT 700  // 窗口高度
#define REFRESH_INTERVAL 10// 刷新间隔

#define BG_SPEED 1 // 背景平移速度
#define BG_PATH ":/recource/background.jpg"
#define PLAN_PATH ":/recource/timg.jpg"
#endif // CONFIG_H
