#include "mainwindow.h"
#include "background.h"
#include "config.h"
#include <QWidget>
#include <QPainter>
#include <QtDebug>

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent)
{
    setFixedSize(WIN_WIDTH,WIN_HEIGHT);  // 初始化窗口，设置长框
    setWindowTitle("Aircraft War");  // 设置标题
    timer.setInterval(REFRESH_INTERVAL);  // 设置刷新间隔为10ms

    initGame();



}

MainWindow::~MainWindow()
{

}

void MainWindow::initGame(){
    timer.start();
    connect(&timer,&QTimer::timeout,[=](){
            //更新游戏中元素的坐标
            updatePosition();
            //重新绘制图片
            update();
        });
}

void MainWindow::updatePosition(){
    background.BGPan();  // 更新坐标
}

void MainWindow::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    qDebug() << 123131;

    painter.drawPixmap(0,background.BGy1,background.BG1);  // 参数（x,y,Qpixmap对象)
    painter.drawPixmap(0,background.BGy2,background.BG2);
    painter.drawPixmap(plane.planeX,plane.planeY,plane.plane);
}

