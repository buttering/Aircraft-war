#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QPaintEvent>
#include "background.h"
#include "plane.h"
class MainWindow : public QWidget
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void paintEvent(QPaintEvent *event);//绘图事件
    void initGame();  //启动游戏
    void updatePosition();//更新坐标
    BackGround background;//私有背景图片对象
    Plane plane; // 飞机对象
    QTimer timer;  //定时器
private:




};

#endif // MAINWINDOW_H
