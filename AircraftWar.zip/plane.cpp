#include "plane.h"
#include "config.h"

Plane::Plane()
{
    plane.load(PLAN_PATH);

    planeX = WIN_WIDTH * 5 - plane.width()*0.5;
    planeY = WIN_HEIGHT - plane.height();

    rect.setWidth(plane.width());
    rect.setHeight(plane.height());
    rect.moveTo(planeX,planeY);
}

void Plane::setPosition(int x, int y){
    planeX = x;
    planeY = y;
    rect.moveTo(planeX,planeY);
}

void Plane::shoot(){

}
